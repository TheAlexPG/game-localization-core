"""CLI package for Game Translator"""

__version__ = "1.0.0"